#!/bin/bash

echo

echo "                _ _        _     _                       _                      _            _             _   "
echo "__   _____ _ __(_) |_ __ _| |__ | | ___       _ __   ___| |___      _____  _ __| | __    ___| |_ __ _ _ __| |_ "
echo "\ \ / / _ \ '__| | __/ _\` | '_ \| |/ _ \_____| '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ /   / __| __/ _\` | '__| __|"
echo " \ V /  __/ |  | | || (_| | |_) | |  __/_____| | | |  __/ |_ \ V  V / (_) | |  |   <    \__ \ || (_| | |  | |_ "
echo "  \_/ \___|_|  |_|\__\__,_|_.__/|_|\___|     |_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_\   |___/\__\__,_|_|   \__|"
echo "                                                                                                               "
echo
echo "Veritable Business Network end-to-end test"
echo
CHANNEL_NAME="$1"
DELAY="$2"
LANGUAGE="$3"
TIMEOUT="$4"
VERBOSE="$5"
NO_CHAINCODE="$6"
: ${CHANNEL_NAME:="veritable-channel"}
: ${DELAY:="3"}
: ${LANGUAGE:="node"}
: ${TIMEOUT:="10"}
: ${VERBOSE:="false"}
: ${NO_CHAINCODE:="false"}
LANGUAGE=`echo "$LANGUAGE" | tr [:upper:] [:lower:]`
COUNTER=1
MAX_RETRY=10

CC_SRC_PATH="github.com/chaincode/veritable/javascript"
if [ "$LANGUAGE" = "node" ]; then
	CC_SRC_PATH="/opt/gopath/src/github.com/chaincode/veritable/javascript"
fi

#if [ "$LANGUAGE" = "java" ]; then
#	CC_SRC_PATH="/opt/gopath/src/github.com/chaincode/fabcar/java/"
#fi

echo "Channel name : "$CHANNEL_NAME

# import utils
. scripts/utils.sh

createChannel() {
	setGlobals 0 1

	if [ -z "$CORE_PEER_TLS_ENABLED" -o "$CORE_PEER_TLS_ENABLED" = "false" ]; then
                set -x
		peer channel create -o orderer.veritable.com:7050 -c $CHANNEL_NAME -f ./channel-artifacts/channel.tx >&log.txt
		res=$?
                set +x
	else
				set -x
		peer channel create -o orderer.veritable.com:7050 -c $CHANNEL_NAME -f ./channel-artifacts/channel.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA >&log.txt
		res=$?
				set +x
	fi
	cat log.txt
	verifyResult $res "Channel creation failed"
	echo "===================== Channel '$CHANNEL_NAME' created ===================== "
	echo
}

joinChannel () {
	for org in 1 2 3; do
	    for peer in 0 1; do
		joinChannelWithRetry $peer $org
		echo "===================== peer${peer}.${ORG_NAME} joined channel '$CHANNEL_NAME' ===================== "
		sleep $DELAY
		echo
	    done
	done
}

## Create channel
echo "Creating channel..."
createChannel

## Join all the peers to the channel
echo "Having all peers join the channel..."
joinChannel

## Set the anchor peers for each org in the channel
echo "Updating anchor peers for notary..."
updateAnchorPeers 0 1
echo "Updating anchor peers for client..."
updateAnchorPeers 0 2
echo "Updating anchor peers for parties..."
updateAnchorPeers 0 3

if [ "${NO_CHAINCODE}" != "true" ]; then

	echo "Installing chaincode on peer0.notary..."
	installChaincode 0 1
	echo "Installing chaincode on peer1.notary..."
	installChaincode 1 1
	echo "Install chaincode on peer0.client..."
	installChaincode 0 2
	echo "Install chaincode on peer1.client..."
	installChaincode 1 2
	echo "Install chaincode on peer0.parties..."
	installChaincode 0 3
	echo "Install chaincode on peer1.parties..."
	installChaincode 1 3
	echo "Instantiating chaincode on peer0.client..."
	instantiateChaincode 0 1
	
fi

echo
echo "========= All GOOD, Veritable Business Network execution completed =========== "
echo

echo
echo "                _ _        _     _                       _                      _         __          _ "
echo "__   _____ _ __(_) |_ __ _| |__ | | ___       _ __   ___| |___      _____  _ __| | __    /__\ __   __| |"
echo "\ \ / / _ \ '__| | __/ _\` | '_ \| |/ _ \_____| '_ \ / _ \ __\ \ /\ / / _ \| '__| |/ /   /_\| '_ \ / _\` |"
echo " \ V /  __/ |  | | || (_| | |_) | |  __/_____| | | |  __/ |_ \ V  V / (_) | |  |   <   //__| | | | (_| |"
echo "  \_/ \___|_|  |_|\__\__,_|_.__/|_|\___|     |_| |_|\___|\__| \_/\_/ \___/|_|  |_|\_\  \__/|_| |_|\__,_|"
echo "                                                                                                        "
echo

exit 0
